package lexicalAnalyzer;

import java.util.Iterator;
import tokens.Token;

public interface Scanner extends Iterator<Token> {

	
}
