package lexicalAnalyzer;

import tokens.Token;

public interface Lextant {
	public String getLexeme();
	public Token prototype();
}
